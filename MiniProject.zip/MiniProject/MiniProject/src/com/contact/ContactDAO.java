package com.contact;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ContactDAO {
	 
    private static final Map<String, Contact> cMap = new HashMap<String, Contact>();
 
    static {
        initContacts();
    }
 
    private static void initContacts() {
        Contact c1 = new Contact("Akesh", "Mohan","+9898989");
        Contact c2 = new Contact("Swathi", "Sha","+86868686");
        Contact c3 = new Contact ("Akhil", "Mohan", "+985635");
 
        cMap.put(c1.getFirstName(), c1);
        cMap.put(c2.getFirstName(), c2);
        cMap.put(c3.getFirstName(), c3);
    }
 
    public static Contact getFirstName(String firstName) {
        return cMap.get(firstName);
    }
 
    public static Contact addContact(Contact c) {
        cMap.put(c.getFirstName(), c);
        return c;
    }
 
    public static Contact updateContact(Contact c) {
        cMap.put(c.getFirstName(), c);
        return c;
    }
 
    public static void deleteContact(String firstName) {
        cMap.remove(firstName);
    }
 
    public static List<Contact> getAllContacts() {
        Collection<Contact> co = cMap.values();
        List<Contact> list = new ArrayList<Contact>();
        list.addAll(co);
        return list;
    }
     
    List<Contact> list;
 
}