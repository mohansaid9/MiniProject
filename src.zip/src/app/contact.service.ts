import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { Contact } from './contact';



@Injectable({
  providedIn: 'root'
})



export class ContactService {

  

baseUrl: string = 'http://localhost:8080/MiniProject/rest/ContactService/';
  

constructor(private myhttp:HttpClient) { }

  


findContact(firstName: string): Observable<Contact> 
  {
    

return this.myhttp.get<Contact>(this.baseUrl + "getContact/" + firstName);
  }

  


findAllContacts() :Observable<Contact[]>
  {
   

return this.myhttp.get<Contact[]>(this.baseUrl+"getContacts/");
  }

  


addNewContact(newContact: Contact): Observable<Contact>
  {
   

return this.myhttp.post<Contact>(this.baseUrl+"addContact/",newContact);
  }

  


modifyContact(existingContact: Contact) : Observable<Contact>
  {
    

return this.myhttp.put<Contact>(this.baseUrl + "updateContact/", existingContact);
  }
  
  

deleteContact(firstName: string) : Observable<Contact>
  {
   

 return this.myhttp.delete<Contact>(this.baseUrl + "deleteContact/" + firstName);
                    
  }

}