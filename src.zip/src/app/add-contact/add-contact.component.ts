import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styles: []
})


export class AddContactComponent {
    Contact: Contact = new Contact();
    constructor(private service: ContactService) { }

  
addNewContact() {
    //alert(JSON.stringify(this.carPart));
    
this.service.addNewContact(this.Contact).subscribe(data => {
      alert(JSON.stringify(data));
    })
  }

}