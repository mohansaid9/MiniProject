export class Contact {
    
    firstName : string;
    lastName : string;
    contactNumber : string;
}