import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-view-all-contact',
  templateUrl: './view-all-contact.component.html',
  styleUrls: ['./view-all-contact.component.css']
})
export class ViewAllContactComponent implements OnInit {
  firstName: string = null;

  contacts: Contact[];
  tempContacts: Contact[];

  private subscription: Subscription;
  
  constructor(private contactService: ContactService) { }
  // http://localhost:4200/category
  ngOnInit() {
    // subscribe will read the latest category vale
    this.subscription = this.contactService.findAllContacts()
    .subscribe((data: Contact[]) => {
                    this.contacts = data;
                    this.tempContacts = data;
                   // console.log(this.tempDepts);
                   // console.log(this.depts);
                }, (err) => {
                    console.log(err);
                });
    }

    deleteContact(x: string)
    {
      //alert('deleting department '+deptNumber);
      console.log('contact name searched '+x);
      this.contactService.deleteContact(x)
      .subscribe((data: Contact) => {
        
        if(data == null)  {
          //console.log(x+' is not matched : '+data.deptNumber);
          this.tempContacts = this.contacts.filter(d => (d.firstName != x) );
          this.contacts = this.tempContacts;
          console.log('Record deleted '+x);
        }
        /*else {
          console.log(x+' is NOT matched : '+data.deptNumber);
          this.tempDepts = this.depts;
        }*/

    }, (err) => {
        console.log(err);
    });
    }

    updateContactArray() {
      if(this.firstName == "null")  {
        console.log('its null : '+this.firstName);
        this.tempContacts = this.contacts;
      }
      else {
        console.log('its not null : '+this.firstName);
        this.tempContacts = this.contacts.filter(d => (d.firstName == this.firstName) );
        //console.log('d : '+d.deptNumber+ '  dname : '+d.deptName+ ' dloc : '+d.deptLocation);
        console.log('tempContacts length : '+this.tempContacts.length);
        console.log('contacts length : '+this.contacts.length);
        
      }
      
    }

 

}
