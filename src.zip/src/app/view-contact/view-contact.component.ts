import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {

  contactObj: Contact;

  constructor(private contactService: ContactService) {
    
  }
  ngOnInit() { //3

      this.contactService.findContact(this.contactObj.firstName)
      .subscribe((data: Contact) => {
          this.contactObj = data;
      }, (err) => {
          console.log(err);
      })
      
  }

}
